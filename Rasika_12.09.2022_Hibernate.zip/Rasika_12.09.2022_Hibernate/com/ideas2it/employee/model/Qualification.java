package com.ideas2it.employee.model;

public class Qualification{

    private int qualificationId;
    private String qualification;
    
    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    } 

    public int getQualificationId() {
        return qualificationId;
    }

    public void setQualificationId(int qualificationId) {
        this.qualificationId = qualificationId;
    } 

    
}

