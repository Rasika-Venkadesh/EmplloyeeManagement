package com.ideas2it.employee.common;

public class CommonUtil {
    public static int employeeId;
}
