//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.ideas2it.employee.customException;

public class TrainerNotFoundException extends RuntimeException {
    public TrainerNotFoundException(String errorMessage) {
        super(errorMessage);
    }
}
