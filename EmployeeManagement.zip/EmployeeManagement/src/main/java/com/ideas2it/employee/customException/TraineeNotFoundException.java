//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package com.ideas2it.employee.customException;

public class TraineeNotFoundException extends RuntimeException {
    public TraineeNotFoundException(String errorMessage) {
        super(errorMessage);
    }
}

